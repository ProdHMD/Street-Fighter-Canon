<?php
/**
 * Plugin Name: WP Rocket
 * Plugin URI: https://wp-rocket.me
 * Description: The best WordPress performance plugin.
 * Version: 3.23.3.3
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Code Name: Iego
 * Author: WP Media
 * Author URI: https://wp-media.me
 * Licence: GPLv2 or later
 *
 * Text Domain: rocket
 * Domain Path: /languages
 *
 * Copyright 2013-2026 WP Rocket
 */

defined( 'ABSPATH' ) || exit;

// Rocket defines.
define( 'WP_ROCKET_VERSION',               '3.23.3.3' );
define( 'WP_ROCKET_WP_VERSION',            '5.8' );
define( 'WP_ROCKET_WP_VERSION_TESTED',     '6.3.1' );
define( 'WP_ROCKET_PHP_VERSION',           '7.4' );
define( 'WP_ROCKET_PRIVATE_KEY',           false );
define( 'WP_ROCKET_SLUG',                  'wp_rocket_settings' );
define( 'WP_ROCKET_WEB_MAIN',              'https://wp-rocket.me/' );
define( 'WP_ROCKET_WEB_API',               WP_ROCKET_WEB_MAIN . 'api/wp-rocket/' ); // only used in deprecated code.
define( 'WP_ROCKET_WEB_CHECK',             WP_ROCKET_WEB_MAIN . 'check_update.php' ); // only used in deprecated code.
define( 'WP_ROCKET_WEB_VALID',             WP_ROCKET_WEB_MAIN . 'valid_key.php' ); // only used in deprecated code.
define( 'WP_ROCKET_WEB_INFO',              WP_ROCKET_WEB_MAIN . 'plugin_information.php' ); // only used in deprecated code.
define( 'WP_ROCKET_FILE',                  __FILE__ );
define( 'WP_ROCKET_PATH',                  realpath( plugin_dir_path( WP_ROCKET_FILE ) ) . '/' );
define( 'WP_ROCKET_INC_PATH',              realpath( WP_ROCKET_PATH . 'inc/' ) . '/' );

require_once WP_ROCKET_INC_PATH . 'constants.php';

define( 'WP_ROCKET_DEPRECATED_PATH',       realpath( WP_ROCKET_INC_PATH . 'deprecated/' ) . '/' );
define( 'WP_ROCKET_FRONT_PATH',            realpath( WP_ROCKET_INC_PATH . 'front/' ) . '/' );
define( 'WP_ROCKET_ADMIN_PATH',            realpath( WP_ROCKET_INC_PATH . 'admin' ) . '/' );
define( 'WP_ROCKET_ADMIN_UI_PATH',         realpath( WP_ROCKET_ADMIN_PATH . 'ui' ) . '/' );
define( 'WP_ROCKET_ADMIN_UI_MODULES_PATH', realpath( WP_ROCKET_ADMIN_UI_PATH . 'modules' ) . '/' );
define( 'WP_ROCKET_COMMON_PATH',           realpath( WP_ROCKET_INC_PATH . 'common' ) . '/' );
define( 'WP_ROCKET_FUNCTIONS_PATH',        realpath( WP_ROCKET_INC_PATH . 'functions' ) . '/' );
define( 'WP_ROCKET_VENDORS_PATH',          realpath( WP_ROCKET_INC_PATH . 'vendors' ) . '/' );
define( 'WP_ROCKET_3RD_PARTY_PATH',        realpath( WP_ROCKET_INC_PATH . '3rd-party' ) . '/' );
if ( ! defined( 'WP_ROCKET_CONFIG_PATH' ) ) {
	define( 'WP_ROCKET_CONFIG_PATH',       WP_CONTENT_DIR . '/wp-rocket-config/' );
}
define( 'WP_ROCKET_URL',                   plugin_dir_url( WP_ROCKET_FILE ) );
define( 'WP_ROCKET_INC_URL',               WP_ROCKET_URL . 'inc/' );
define( 'WP_ROCKET_ADMIN_URL',             WP_ROCKET_INC_URL . 'admin/' );
define( 'WP_ROCKET_ASSETS_URL',            WP_ROCKET_URL . 'assets/' );
define( 'WP_ROCKET_ASSETS_PATH',            WP_ROCKET_PATH . 'assets/' );
define( 'WP_ROCKET_ASSETS_JS_URL',         WP_ROCKET_ASSETS_URL . 'js/' );
define( 'WP_ROCKET_ASSETS_JS_PATH',         WP_ROCKET_ASSETS_PATH . 'js/' );
define( 'WP_ROCKET_ASSETS_CSS_URL',        WP_ROCKET_ASSETS_URL . 'css/' );
define( 'WP_ROCKET_ASSETS_IMG_URL',        WP_ROCKET_ASSETS_URL . 'img/' );

if ( ! defined( 'WP_ROCKET_CACHE_ROOT_PATH' ) ) {
	define( 'WP_ROCKET_CACHE_ROOT_PATH', WP_CONTENT_DIR . '/cache/' );
}
define( 'WP_ROCKET_CACHE_PATH',         WP_ROCKET_CACHE_ROOT_PATH . 'wp-rocket/' );
define( 'WP_ROCKET_MINIFY_CACHE_PATH',  WP_ROCKET_CACHE_ROOT_PATH . 'min/' );
define( 'WP_ROCKET_CACHE_BUSTING_PATH', WP_ROCKET_CACHE_ROOT_PATH . 'busting/' );
define( 'WP_ROCKET_CRITICAL_CSS_PATH',  WP_ROCKET_CACHE_ROOT_PATH . 'critical-css/' );

define( 'WP_ROCKET_USED_CSS_PATH',  WP_ROCKET_CACHE_ROOT_PATH . 'used-css/' );

if ( ! defined( 'WP_ROCKET_CACHE_ROOT_URL' ) ) {
	define( 'WP_ROCKET_CACHE_ROOT_URL', WP_CONTENT_URL . '/cache/' );
}
define( 'WP_ROCKET_CACHE_URL',         WP_ROCKET_CACHE_ROOT_URL . 'wp-rocket/' );
define( 'WP_ROCKET_MINIFY_CACHE_URL',  WP_ROCKET_CACHE_ROOT_URL . 'min/' );
define( 'WP_ROCKET_CACHE_BUSTING_URL', WP_ROCKET_CACHE_ROOT_URL . 'busting/' );

define( 'WP_ROCKET_USED_CSS_URL', WP_ROCKET_CACHE_ROOT_URL . 'used-css/' );

if ( ! defined( 'CHMOD_WP_ROCKET_CACHE_DIRS' ) ) {
	define( 'CHMOD_WP_ROCKET_CACHE_DIRS', 0755 ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
}
if ( ! defined( 'WP_ROCKET_LASTVERSION' ) ) {
	define( 'WP_ROCKET_LASTVERSION', '3.22.1' );
}

/**
 * We use is_readable() with @ silencing as WP_Filesystem() can use different methods to access the filesystem.
 *
 * This is more performant and more compatible. It allows us to work around file permissions and missing credentials.
 */
if ( @is_readable( WP_ROCKET_PATH . 'licence-data.php' ) ) { //phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	@include WP_ROCKET_PATH . 'licence-data.php'; //phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
}

require WP_ROCKET_INC_PATH . 'compat.php';
require WP_ROCKET_INC_PATH . 'classes/class-wp-rocket-requirements-check.php';

/**
 * GPL Vault: licenses WP Rocket locally, keeps its licence/SaaS traffic offline and
 * disables telemetry. Additive hooks only - delete through "END GPL Vault" to restore
 * upstream behaviour. Do not reinstate licence-data.php: the plugin removes it itself
 * once a licence validates, and its constants disable the licence field.
 */
if ( ! defined( 'WP_ROCKET_WHITE_LABEL_ACCOUNT' ) ) {
	define( 'WP_ROCKET_WHITE_LABEL_ACCOUNT', true );
}

add_filter( 'pre_option_rocket_mixpanel_optin', '__return_zero' );
add_filter( 'pre_option_rocket_analytics_notice_displayed', '__return_true' );
add_filter( 'rocket_hide_rocketcdn_notices', '__return_true' );
add_filter( 'rocket_show_rocketcdn_banner', '__return_false' );

/**
 * Returns the licence consumer email.
 *
 * @return string
 */
function rocket_gplvault_email() {
	return 'license@example.com';
}

/**
 * Returns the licence consumer key.
 *
 * @return string
 */
function rocket_gplvault_consumer_key() {
	return '1415B451';
}

/**
 * Returns the licence secret key.
 *
 * @return string
 */
function rocket_gplvault_secret_key() {
	return hash( 'crc32', rocket_gplvault_email() );
}

add_filter( 'pre_get_rocket_option_consumer_key', 'rocket_gplvault_consumer_key' );
add_filter( 'pre_get_rocket_option_consumer_email', 'rocket_gplvault_email' );
add_filter( 'pre_get_rocket_option_secret_key', 'rocket_gplvault_secret_key' );

add_filter( 'pre_option_wp_rocket_no_licence', '__return_zero' );
add_filter( 'pre_transient_wp_rocket_no_licence', '__return_zero' );
add_filter( 'pre_get_rocket_option_wp_rocket_no_licence', '__return_zero' );

/**
 * Returns the mock customer record, pinned to the top ("Infinite") tier.
 *
 * @return object
 */
function rocket_gplvault_customer_data() {
	return (object) [
		'licence_account'        => -1,
		'licence_expiration'     => time() + ( 50 * YEAR_IN_SECONDS ),
		'licence'                => (object) [
			'name'                      => 'Infinite',
			'is_revoked'                => false,
			'plugin_updates_ban_reason' => '',
		],
		'status'                 => 'valid',
		'is_reseller'            => false,
		'has_auto_renew'         => true,
		'date_created'           => time() - ( 30 * DAY_IN_SECONDS ),
		'performance_monitoring' => (object) [
			'expiration'   => time() + ( 50 * YEAR_IN_SECONDS ),
			'cancelled_at' => null,
			'manage_url'   => null,
			'active_sku'   => 'perf-monitor-advanced',
			'plans'        => [
				(object) [
					'sku'    => 'perf-monitor-advanced',
					'title'  => 'Advanced',
					'status' => 'active',
					'button' => (object) [
						'label'  => 'Your plan',
						'action' => 'none',
						'url'    => null,
					],
				],
			],
		],
	];
}

add_filter( 'pre_transient_wp_rocket_customer_data', 'rocket_gplvault_customer_data' );

/**
 * Answers the licence and SaaS endpoints locally so no request leaves the site.
 *
 * @param false|array $response Preempted response.
 * @param array       $args     Request arguments.
 * @param string      $url      Request URL.
 * @return false|array
 */
function rocket_gplvault_http( $response, $args, $url ) {
	if ( false !== strpos( $url, 'mixpanel.com' ) || false !== strpos( $url, 'mxpnl.com' ) ) {
		return [
			'response' => [ 'code' => 200 ],
			'body'     => '1',
		];
	}

	if ( false !== strpos( $url, 'api.wp-rocket.me' ) ) {
		if ( false !== strpos( $url, 'valid_key.php' ) ) {
			return [
				'response' => [ 'code' => 200 ],
				'body'     => wp_json_encode(
					[
						'success' => true,
						'data'    => [
							'consumer_key'   => rocket_gplvault_consumer_key(),
							'consumer_email' => rocket_gplvault_email(),
							'secret_key'     => rocket_gplvault_secret_key(),
						],
					]
				),
			];
		}

		if ( false !== strpos( $url, 'stat/1.0/wp-rocket/user.php' ) ) {
			return [
				'response' => [ 'code' => 200 ],
				'body'     => wp_json_encode( rocket_gplvault_customer_data() ),
			];
		}

		if ( false !== strpos( $url, 'check_update.php' ) ) {
			return [
				'response' => [ 'code' => 200 ],
				'body'     => wp_json_encode(
					[
						'version'      => WP_ROCKET_VERSION,
						'details_url'  => '',
						'download_url' => '',
					]
				),
			];
		}
	}

	foreach ( [ 'api.wp-rocket.me', 'saas.wp-rocket.me', 'cpcss.wp-rocket.me' ] as $service_host ) {
		if ( false !== strpos( $url, $service_host ) ) {
			return [
				'response' => [ 'code' => 200 ],
				'body'     => wp_json_encode(
					[
						'code'    => 200,
						'message' => 'OK',
					]
				),
			];
		}
	}

	return $response;
}

add_filter( 'pre_http_request', 'rocket_gplvault_http', 10, 3 );

// END GPL Vault.

/**
 * Loads WP Rocket translations
 *
 * @since 3.0
 * @author Remy Perona
 *
 * @return void
 */
function rocket_load_textdomain() {
	load_plugin_textdomain( 'rocket', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'init', 'rocket_load_textdomain' );

$wp_rocket_requirement_checks = new WP_Rocket_Requirements_Check(
	[
		'plugin_name'         => 'WP Rocket',
		'plugin_file'         => WP_ROCKET_FILE,
		'plugin_version'      => WP_ROCKET_VERSION,
		'plugin_last_version' => WP_ROCKET_LASTVERSION,
		'wp_version'          => WP_ROCKET_WP_VERSION,
		'php_version'         => WP_ROCKET_PHP_VERSION,
	]
);

if ( $wp_rocket_requirement_checks->check() ) {
	require WP_ROCKET_INC_PATH . 'main.php';
}

unset( $wp_rocket_requirement_checks );
