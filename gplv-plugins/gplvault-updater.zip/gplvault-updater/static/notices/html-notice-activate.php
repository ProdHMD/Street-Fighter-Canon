<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="gv_activation_message" class="notice notice-error">
	<p><strong><?php esc_html_e( 'GPLVault Updater License Activation', 'gplvault-updater' ); ?></strong>
		&#8211; <?php esc_html_e( 'Please activate your license to access GPLVault themes and plugins.', 'gplvault-updater' ); ?></p>
</div>
<?php
