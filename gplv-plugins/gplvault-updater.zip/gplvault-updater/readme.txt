=== GPLVault Update Manager ===
Contributors: gplvault
Tags: updates, automatic updates, plugin updates, theme updates, gplvault
Requires at least: 5.9
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 5.3.9
License: GPL v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Network: true

Keep your WordPress site in sync with all plugins and themes from GPLVault.com through automated updates and license management.

== Description ==

GPLVault Update Manager is a powerful WordPress plugin that seamlessly integrates your website with the GPLVault.com repository, providing automatic updates for premium WordPress plugins and themes. This plugin ensures your site stays current with the latest versions of GPLVault items while maintaining security and stability.

= Key Features =

* **Automatic Updates**: Receive automatic updates for all GPLVault plugins and themes
* **License Management**: Easy license activation and management through the WordPress admin
* **Native WordPress Integration**: Updates are delivered through WordPress's native update system
* **Selective Updates**: Exclude specific plugins or themes from automatic updates
* **Update Logs**: Comprehensive logging system for tracking update history and troubleshooting
* **Weekly Catalog Refresh**: Automatic weekly synchronization with the GPLVault catalog
* **Security First**: All updates are delivered securely with proper authentication

= How It Works =

1. Install and activate the GPLVault Update Manager plugin
2. Enter your GPLVault license key in the settings
3. The plugin automatically checks for updates and notifies you through WordPress
4. Update your plugins and themes directly from the WordPress admin interface

= Requirements =

* WordPress 5.9 or higher (verified compatible through WordPress 7.1)
* PHP 7.4 or higher (verified compatible through PHP 8.5)
* Active GPLVault license
* SSL-enabled hosting (recommended)

== Installation ==

= From WordPress Admin =

1. Navigate to Plugins > Add New
2. Upload the `gplvault-updater.zip` file
3. Click "Install Now" and then "Activate"
4. Go to GPLVault > Settings to configure your license

= Manual Installation =

1. Upload the `gplvault-updater` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to GPLVault > Settings
4. Enter your GPLVault license key and click "Activate"

= For Multisite Networks =

1. Upload the plugin files to `/wp-content/plugins/`
2. Network activate the plugin from the Network Admin > Plugins page
3. Configure the license key from the Network Admin > GPLVault > Settings

== Frequently Asked Questions ==

= How do I get a GPLVault license key? =

You can purchase a license key from [GPLVault.com](https://www.gplvault.com). Different subscription plans are available based on your needs.

= Why is my license showing as inactive? =

Common reasons include:
* Incorrect license key entry
* Expired subscription
* License key used on too many sites
* Connection issues with GPLVault servers

Check your license status at GPLVault.com or contact support — we can help.

= Can I exclude certain plugins or themes from updates? =

Yes! Navigate to GPLVault > Disable Updates where you can select specific plugins or themes to exclude from automatic updates.

= How often does the plugin check for updates? =

The plugin checks for updates according to WordPress's standard update schedule. A weekly catalog refresh also keeps everything current.

= Where can I view update logs? =

Go to GPLVault > Logs to view detailed logs of all update activities, API communications, and system events.

= Is my license key secure? =

Yes, your license key is stored securely in the WordPress database and is masked in the admin interface for additional security.

= What happens if I deactivate my license? =

Deactivating your license will stop automatic updates from GPLVault. You can reactivate it at any time with a valid subscription.

= Which PHP versions are supported? =

GPLVault Update Manager is compatible with PHP 7.4, 8.0, 8.1, 8.2, 8.3, 8.4, and 8.5. We verify compatibility against this full range with each release using static analysis (PHPCompatibilityWP) and syntax linting.

== Screenshots ==

1. **Settings Page** - Material Design interface for license activation and management
2. **Plugin Exclusions** - Interactive interface with search and bulk selection for excluding plugins
3. **Theme Exclusions** - Modern card-based layout for managing theme update exclusions
4. **Logs Page** - Comprehensive logging interface with environment info and export options
5. **Update Integration** - GPLVault updates seamlessly integrated into WordPress updates page

== Changelog ==

For the full changelog, please see changelog.txt included with the plugin.

= 5.3.9 - 2026-08-21 =
* Fixed: False "license key has not been activated" notices from some WooCommerce.com marketplace plugins after version 5.3.8.
* Fixed: The copy buttons on the Logs and Environment tabs now work in modern browsers.
* Improved: Added extra permission checks to admin actions.
* Improved: Rewrote error messages and help text in plain English.
* Improved: Tested and verified with WordPress 7.1.

= 5.3.8 - 2026-05-22 =
* Fixed: Plugins distributed with a `Woo:` header (such as WooCommerce.com subscription products) now update correctly through GPL Vault.
* Improved: Faster admin pages and API requests through reduced redundant file parsing.
* Improved: Verified compatibility with WordPress 7.0 GA (released 2026-05-20).

= 5.3.7 - 2026-05-12 =
* Improved: Verified compatibility with WordPress 7.0.
* Improved: Verified compatibility across PHP 7.4 through PHP 8.5.

= 5.3.6 - 2026-04-11 =
* Added: Translations for 13 languages.
* Optimized: Leaner plugin initialization.


== Upgrade Notice ==

= 5.3.9 =
Removes the false "license key has not been activated" notices that some WooCommerce.com marketplace plugins showed after version 5.3.8. Recommended for all users who run WooCommerce.

= 5.3.8 =
Fixes a WooCommerce conflict that prevented updates for plugins carrying a `Woo:` header (affects ~85% of WooThemes-style plugins). Recommended for all users running WooCommerce alongside GPL Vault.

= 5.3.4 =
Enhanced WordPress coding standards compliance. Recommended for all users.

= 5.3.0 =
Major UI/UX update! Complete Material Design refresh with interactive search, bulk actions, and improved user experience. Recommended for all users.

= 5.2.7 =
Important update for WordPress 6.7+ compatibility. Fixes translation loading issues and improves performance.

= 5.2.6 =
Security enhancements and improved admin interface text. Recommended update for all users.

== Additional Information ==

= Support =

For support, please visit [GPLVault.com](https://www.gplvault.com) or contact our support team.

= Privacy =

This plugin communicates with GPLVault.com servers to:
* Verify license validity
* Retrieve update information
* Download plugin and theme updates

No personal data is collected beyond the license key and site URL necessary for license verification.

= Contributing =

For bug reports and feature requests, please contact GPLVault support.
