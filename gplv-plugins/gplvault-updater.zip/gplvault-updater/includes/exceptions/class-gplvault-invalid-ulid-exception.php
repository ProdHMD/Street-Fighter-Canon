<?php

defined( 'ABSPATH' ) || exit;

class GPLVault_Invalid_Ulid_Exception extends InvalidArgumentException {}
