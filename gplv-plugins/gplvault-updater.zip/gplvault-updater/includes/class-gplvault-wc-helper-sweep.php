<?php

defined( 'ABSPATH' ) || exit;

/**
 * Removes update entries that have no download URL from the plugin and theme update
 * transients, so WordPress does not attempt a download that cannot succeed. Entries
 * that carry a valid download URL, items managed by GPL Vault, and entries owned by
 * an active update source are all left untouched.
 */
class GPLVault_WC_Helper_Sweep {

	const FLUSH_MARKER_OPTION = 'gplvault_wc_helper_sweep_flushed_v1';

	const WC_HELPER_ID_PREFIX = 'woocommerce-com-';

	private static $instance;

	private static $initiated = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function init() {
		if ( true === self::$initiated ) {
			return;
		}
		self::$initiated = true;

		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'sweep_plugins' ), PHP_INT_MAX );
		add_filter( 'site_transient_update_plugins', array( $this, 'sweep_plugins' ), PHP_INT_MAX );

		add_filter( 'pre_set_site_transient_update_themes', array( $this, 'sweep_themes' ), PHP_INT_MAX );
		add_filter( 'site_transient_update_themes', array( $this, 'sweep_themes' ), PHP_INT_MAX );

		add_action( 'init', array( $this, 'maybe_flush_header_caches' ), 1 );
	}

	public function sweep_plugins( $transient ) {
		if ( ! $this->has_response( $transient ) || $this->update_manager_active() ) {
			return $transient;
		}

		$gv_managed = GPLVault_Helper::gv_plugins( false );

		foreach ( $transient->response as $plugin_file => $entry ) {
			if ( isset( $gv_managed[ $plugin_file ] ) ) {
				continue;
			}

			if ( $this->is_wc_helper_entry( $entry ) && $this->is_empty_package( $entry ) ) {
				unset( $transient->response[ $plugin_file ] );
			}
		}

		return $transient;
	}

	public function sweep_themes( $transient ) {
		if ( ! $this->has_response( $transient ) || $this->update_manager_active() ) {
			return $transient;
		}

		$all_themes = GPLVault_Helper::all_themes( false );
		$gv_managed = GPLVault_Helper::gv_themes( false );

		foreach ( $transient->response as $theme_slug => $entry ) {
			if ( isset( $gv_managed[ $theme_slug ] ) ) {
				continue;
			}

			if ( $this->theme_has_woo_header( $all_themes, $theme_slug ) && $this->is_empty_package( $entry ) ) {
				unset( $transient->response[ $theme_slug ] );
			}
		}

		return $transient;
	}

	/**
	 * Clears the plugin and theme metadata caches once, so header data is reparsed.
	 * Gated by an autoloaded option so it runs at most once per site.
	 */
	public function maybe_flush_header_caches() {
		if ( '1' === get_option( self::FLUSH_MARKER_OPTION ) ) {
			return;
		}

		if ( function_exists( 'wp_clean_plugins_cache' ) ) {
			wp_clean_plugins_cache( false );
		}
		if ( function_exists( 'wp_clean_themes_cache' ) ) {
			wp_clean_themes_cache();
		}

		update_option( self::FLUSH_MARKER_OPTION, '1', true );
	}

	private function has_response( $transient ) {
		return is_object( $transient ) && ! empty( $transient->response ) && is_array( $transient->response );
	}

	/**
	 * Whether the update source that owns these entries is active. When it is, its
	 * entries are left for it to handle.
	 */
	private function update_manager_active() {
		if ( ! class_exists( 'WC_Woo_Update_Manager_Plugin' ) ) {
			return false;
		}

		// Read the active-plugins options directly: core is_plugin_active() lives in
		// wp-admin and is not loaded during front-end or cron update checks.
		$main_file = 'woo-update-manager/woo-update-manager.php';

		if ( in_array( $main_file, (array) get_option( 'active_plugins', array() ), true ) ) {
			return true;
		}

		if ( is_multisite() ) {
			$network_active = (array) get_site_option( 'active_sitewide_plugins', array() );
			if ( isset( $network_active[ $main_file ] ) ) {
				return true;
			}
		}

		return false;
	}

	private function is_wc_helper_entry( $entry ) {
		$id = is_object( $entry ) && isset( $entry->id ) ? $entry->id
			: ( is_array( $entry ) && isset( $entry['id'] ) ? $entry['id'] : '' );

		return is_string( $id ) && 0 === strpos( $id, self::WC_HELPER_ID_PREFIX );
	}

	private function theme_has_woo_header( $all_themes, $theme_slug ) {
		return isset( $all_themes[ $theme_slug ] )
			&& $all_themes[ $theme_slug ] instanceof WP_Theme
			&& ! empty( $all_themes[ $theme_slug ]->get( 'Woo' ) );
	}

	private function is_empty_package( $entry ) {
		if ( is_object( $entry ) ) {
			return empty( $entry->package );
		}

		if ( is_array( $entry ) ) {
			return empty( $entry['package'] );
		}

		return false;
	}
}
